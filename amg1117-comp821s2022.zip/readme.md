packages required: Nodejs (conda install nodejs), dotenv (npm install dotenv), Discord.js, Discord Builders, Rest, and Api-Types, aws-sdk

npm install discord.js
npm install @discordjs/builders @discordjs/rest discord-api-types

npm install -g nodemon
npm install aws-sdk

cd into home directory \compdiscordbot and run 'deploy-commands.js' to attach the commands to your server/bot, then run 'node index.js' to start the bot.

Contributors:
TheGam1ngWizard, bmorrisondev